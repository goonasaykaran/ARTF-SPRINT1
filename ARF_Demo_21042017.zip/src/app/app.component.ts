import { Component } from '@angular/core';
// import { rateapproval, rates, pricing, auditentry } from './rates';
import { rateapproval, rates, pricing } from './rates';

@Component({
    selector: 'my-app',
    templateUrl: `./app.component.html`,
    styleUrls: [`./app.component.css`]
})

export class AppComponent { 

	  private gridData: any[] = rates;
    private gridDatachecker: any[] = rateapproval;
		// private gridDataaudit: any[] = auditentry;
		private gridData1: any[] = pricing;
    public gridColumns: any = [
	  {
		"fieldName" : "SerialNumber",
		"title" : "SR#",
		"width" : 25
	  },
	  {
		"fieldName" : "Date",
		"title" : "DATE",
		"width" : 50
	  },
	  {
		"fieldName" : "SourceSystem",
		"title" : "SOURCE SYSTEM",
		"width" : 50
	  },
	  {
		"fieldName" : "BaseRateType",
		"title" : "BASE RATE TYPE",
		"width" : 50
	  },  
	  {
		"fieldName" : "Rate",
		"title" : "RATE",
		"width" : 50
	  }
	];
    
  public value: string = " ";
  public mask: string = " ";
	 public value3: Date = new Date(2000, 2, 10);

	// public value1: Date = new Date();

	public radioItems: Array<{text: string, value: string}> = [
		{text: 'Yes', value: 'Yes'},
		{text: 'No', value: 'No'}
	];
  
	public radioItems1: Array<{text: string, value: string}> = [
		{text: 'Yes', value: 'Yes'},
		{text: 'No', value: 'No'}
	];

	public listItems: Array<string> = ["Bank of New York", "J.P Morgan"];
	public listItems1: Array<string> = ["0", "1", "2","3", "4", "5","6"];
	public listItems2: Array<string> = ["LIBOR", "SIBOR", "XYZ"];

}


