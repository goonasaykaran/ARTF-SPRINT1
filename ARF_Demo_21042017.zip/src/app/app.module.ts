   import { NgModule,ApplicationRef } from '@angular/core';
   import { BrowserModule } from '@angular/platform-browser';
   import { FormsModule } from '@angular/forms';
   import { LayoutModule } from '@progress/kendo-angular-layout';   
   import { HttpModule } from '@angular/http';
   import { RouterModule, PreloadAllModules } from '@angular/router';
   import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
   import { AppComponent } from './app.component';
   import { removeNgStyles, createNewHosts, createInputTransfer } from '@angularclass/hmr';
   import { CSTTextfieldModule, CSTMultiselectModule, CSTDatePickerModule, CSTButtonGroupModule,
         CSTTextareaModule, CSTTooltipModule, CSTButtonModule, CSTDropdownModule, CSTFloatingMenuModule,
         CSTRadioButtonModule, CSTDialogModule, CSTGridModule  } from 'ng2-cst-ui-components';
   import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
   import { CalendarModule } from '@progress/kendo-angular-dateinputs';
   import { ButtonsModule } from '@progress/kendo-angular-buttons';
   import { GridModule } from '@progress/kendo-angular-grid';
   import { InputsModule } from '@progress/kendo-angular-inputs';
   import { DialogModule } from '@progress/kendo-angular-dialog';


   @NgModule({
       bootstrap:    [AppComponent],
       declarations: [AppComponent],
       imports:      [BrowserModule, HttpModule, LayoutModule, CSTTextfieldModule, DateInputsModule,CSTDatePickerModule, 
                      ButtonsModule,DialogModule,GridModule,InputsModule,CSTRadioButtonModule,DropDownsModule,CSTTextareaModule,CSTDatePickerModule,CSTGridModule]
   })
   export class AppModule {  }
